package com.example.checkbox

data class CategoryTitleItem(
    var title: String?,
    var userId: String?,
)